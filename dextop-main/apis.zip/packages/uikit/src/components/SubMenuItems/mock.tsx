const SubMenuItemsMock = [
  {
    label: "Overview",
    href: "/swap",
  },
  {
    label: "Farms",
    href: "/",
  },
  {
    label: "Syrup Pools",
    href: "/",
  },
  {
    label: "Swap",
    href: "/swap",
    iconName: "Swap",
  },
  {
    label: "Trading Competition",
    href: "/",
  },
];

export default SubMenuItemsMock;
