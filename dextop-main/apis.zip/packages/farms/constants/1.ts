import { SerializedFarmConfig } from '@pancakeswap/farms'

const farms: SerializedFarmConfig[] = []

export default farms
